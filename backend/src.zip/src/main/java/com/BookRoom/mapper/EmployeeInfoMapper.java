package com.BookRoom.mapper;

import com.BookRoom.dto.CancelRequest;
import com.BookRoom.entity.account.EmployeeInfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface EmployeeInfoMapper  extends BaseMapper<EmployeeInfo> {
}
