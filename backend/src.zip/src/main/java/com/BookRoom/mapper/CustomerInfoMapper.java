package com.BookRoom.mapper;

import com.BookRoom.dto.CancelRequest;
import com.BookRoom.entity.account.CustomerInfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface CustomerInfoMapper extends BaseMapper<CustomerInfo> {
}
