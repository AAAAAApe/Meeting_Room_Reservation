package com.BookRoom.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.BookRoom.entity.meetingRoom.MeetingRoom;

public interface MeetingRoomMapper extends BaseMapper<MeetingRoom> {
}
