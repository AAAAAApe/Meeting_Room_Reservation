package com.BookRoom.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.BookRoom.entity.account.Role;

public interface RoleMapper extends BaseMapper<Role> {
}