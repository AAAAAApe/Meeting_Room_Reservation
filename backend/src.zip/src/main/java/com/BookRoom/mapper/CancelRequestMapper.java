package com.BookRoom.mapper;

import com.BookRoom.dto.CancelRequest;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CancelRequestMapper extends BaseMapper<CancelRequest> {
}