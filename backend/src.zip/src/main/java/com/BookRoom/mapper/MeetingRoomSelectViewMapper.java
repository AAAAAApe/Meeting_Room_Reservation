package com.BookRoom.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.BookRoom.entity.view.MeetingRoomSelectView;

public interface MeetingRoomSelectViewMapper extends BaseMapper<MeetingRoomSelectView> {
}
