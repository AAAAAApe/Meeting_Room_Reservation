package com.BookRoom.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.BookRoom.entity.view.CustomerView;

public interface CustomerViewMapper extends BaseMapper<CustomerView> {} 
