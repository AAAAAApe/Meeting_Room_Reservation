package com.BookRoom.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.BookRoom.entity.view.MeetingRoomView;

public interface MeetingRoomViewMapper extends BaseMapper<MeetingRoomView> {
}
