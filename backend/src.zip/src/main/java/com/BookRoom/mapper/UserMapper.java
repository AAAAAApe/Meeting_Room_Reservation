package com.BookRoom.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.BookRoom.entity.account.User;

public interface UserMapper extends BaseMapper<User> {
}
