package com.BookRoom.mapper;

import com.BookRoom.entity.meetingRoom.MeetingRoomSelection;
import com.github.jeffreyning.mybatisplus.base.MppBaseMapper;

public interface MeetingRoomSelectionMapper extends MppBaseMapper<MeetingRoomSelection> {
}
