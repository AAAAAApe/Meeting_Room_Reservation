package com.BookRoom.mapper;

import com.BookRoom.entity.sequence.Sequence;
import com.github.jeffreyning.mybatisplus.base.MppBaseMapper;

public interface SequenceMapper extends MppBaseMapper<Sequence> {
}
