package com.BookRoom.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.BookRoom.entity.view.UserView;

public interface UserViewMapper extends BaseMapper<UserView>{

}
