package com.BookRoom.service;

public interface RoleService {
    public Byte getRoleId(String roleName);
    public String getRoleName(Byte roleId);
}
