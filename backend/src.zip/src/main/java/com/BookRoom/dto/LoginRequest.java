package com.BookRoom.dto;

public record LoginRequest(String userId, String password) {}
